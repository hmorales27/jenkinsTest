var lastDivIDs;
var modalOpen = false;
var lastFocus = null;
var modal = getId('bibMulti2');
var mOverlay = getId('bibMultiContainer');

var allNodes = document.querySelectorAll("*");

for (i = 0; i < allNodes.length; i++) {
	console.log(allNodes.item(i));
	allNodes.item(i).addEventListener('focus', focusRestrict);
}

  function focusRestrict ( event ) {
    if ( modalOpen ) {
      event.stopPropagation();
      modal.focus();
    }
  }


  function getId ( id ) {
    return document.getElementById(id);
  }

function showPopupMulti(divid) {
	var tempArr = document.getElementsByClassName('temp');
	for(var i = 0; i < tempArr.length; i++) {
		var temp = tempArr[i];
		temp.removeAttribute('tabindex');
		temp.removeAttribute('class');
	}

	if(this.event) {
		lastFocus = this.event.target;
	}

    mOverlay.setAttribute('aria-hidden', 'false');
    modalOpen = true;


	var divIDs = divid.split(' ');
	var i, item, l;

	var lstmulti = document.getElementById('bibMulti2');
	var innercontent = ' ';

	for ( var i = 0, l = divIDs.length; i < l; i++) {
		// alert(divIDs[i]);
		var lstmsgbox = document.getElementById(divIDs[i]);
		// alert(lstmsgbox.innerHTML);
		innercontent = innercontent + " " + lstmsgbox.innerHTML;

	}
	/*
	innercontent = "<div class=\"refTable\">"
			+ innercontent
			+ "</div><div style=\"text-align: right;\"><a onmouseover=\"this.style.cursor='pointer'\" style=\"font-family: Helvetica; font-size: 14pt;\" onfocus=\"this.blur();\" onclick=\"document.getElementById('bibMulti2').style.display = 'none';\"><span style=\"text-decoration: underline;\">Close</span></a></div>"; */

	innercontent = "<div id=\"refclose\"><a onmouseover=\"this.style.cursor='pointer'\" onfocus=\"this.blur();\" onclick=\"EnableParentPageScroll();\"><span>Close</span></a></div>"
				   + "<div class=\"refTable\">" + innercontent + "</div>";

	lstmulti.innerHTML = innercontent;
	lstmulti.parentNode.style.display = 'block';
	lstmulti.style.display = 'block';

	if (lastDivIDs != null) {
		for ( var i = 0, l = divIDs.length; i < l; i++) {
			var lstmsgbox = document.getElementById(divIDs[i]);
			lstmsgbox.style.display = 'none';
		}
	}
	DisableParentPageScroll();
	modal.setAttribute('tabindex', '0');
    modal.focus();
}

function change() {

	var sp2 = document.getElementById("ja50-ce-abstract");	
	var sp1 = document.getElementById("bibliography");
	var parentDiv = sp2.parentNode;
	parentDiv.insertBefore(sp1, sp2);

}



function toggle(showHideDiv, switchImgTag, isNodeEle) {
        if(isNodeEle) {
		var ele = showHideDiv;
		var imageEle = switchImgTag;
	} else {
		var ele = document.getElementById(showHideDiv);
		var imageEle = document.getElementById(switchImgTag);	
	}
	
	var display = ele.currentStyle ? ele.currentStyle.display : getComputedStyle(ele, null).display;
	if(display == "block") {
		setTimeout(function() {
			ele.style.display = "none";
		}, 10);
		if(imageEle.id == 'image_div_link') {
			imageEle.innerHTML = '<span id="plusminus">+</span> Author Affiliations & Information';
		} else if(imageEle.id == 'expand_collapse') {
			imageEle.innerHTML = '<span class="accor_btn">+</span>Article Info';		
		}		
	} else if(display == "none") {
		setTimeout(function() {
			ele.style.display = "block";
		}, 10);
		if(imageEle.id == 'image_div_link') {
			imageEle.innerHTML = '<span id="plusminus">-</span> Author Affiliations & Information';
		} else if(imageEle.id == 'expand_collapse') {
			imageEle.innerHTML = '<span class="accor_btn l-heigth">-</span>Article Info';		
		}
	}
}

var bodyElement = document.getElementById('content-body');

window.addEventListener('load', function() {
	//change();
}, false);

/*- Author Affiliations hide div.*/
var bodyElement = document.getElementsByClassName('aff')[0];
if (bodyElement == null){
    var el = document.getElementById('author_info_ctrl');
    if(el != null) {
    el.style.display = 'none';	
    }
    
}
/*end*/
var toggleElement = document.getElementById('image_div_link');
if(null != toggleElement) {
toggleElement.href = "http://wwww.kiwidemourl.com";
}
/*
toggleElement.addEventListener('click', function() {
	toggle('author_info', 'image_div_link');
}, false);*/

var articleAuthorGroup = document.getElementsByClassName("author-group");

if(articleAuthorGroup.length != 0) {

	for (var i = articleAuthorGroup.length - 1; i >= 0; i--) {

		var iDiv = document.createElement('div');
		iDiv.id = 'oa-info';
		iDiv.className = 'oa-info';
		//iDiv.innerHTML = "Testing";
		articleAuthorGroup[i].appendChild(iDiv);

		var authorAffiliationsInfo = articleAuthorGroup[i].getElementsByTagName('A');
		var aaiLen = authorAffiliationsInfo.length;
		if(aaiLen) {
			for(var j = 0; j < aaiLen; j++) {
				if(authorAffiliationsInfo[j].id == 'image_div_link') {   					
					authorAffiliationsInfo[j].removeEventListener('click', authorAffiliationsInfoToggle, false);
					authorAffiliationsInfo[j].addEventListener('click', authorAffiliationsInfoToggle, false);
    				}
			}
		}
    		

		/*articleAuthorGroup[i].addEventListener("click", function(e) {
		if(e.target && e.target.nodeName === "A") {
		var newTarget = e.target.parentNode.nextSibling;
		function getValidNode(){
		if (newTarget.nodeName === '#text') {
		newTarget = newTarget.nextSibling;
		getValidNode();
		}
		}
		getValidNode();
		if(newTarget.nodeName === '#text'){
		getValidNode();
		}
		else{
		if(newTarget.nodeName != 'P')
		  {
		  var isDisplay = newTarget.style.display;
		    if (isDisplay === 'block') {
		    newTarget.style.display = 'none';
		    var spanPlusMinus = document.getElementById('plusminus');
		    spanPlusMinus.innerHTML = '+';
		        }else{
		    newTarget.style.display = 'block';
		    var spanPlusMinus = document.getElementById('plusminus');
		    spanPlusMinus.innerHTML = '-';
		    }
		  }
		}
	}
	});*/
	}
}
else {
	var articleHeaderDiv = document.getElementsByClassName("article_header");
	for (var i = articleHeaderDiv.length - 1; i >= 0; i--) {
		var iDiv = document.createElement('div');
		iDiv.id = 'oa-info';
		iDiv.className = 'oa-info';
		//iDiv.innerHTML = "Testing";
		articleHeaderDiv[i].appendChild(iDiv);
	}
}

function showAutherAffiliationDiv(){
var authorinfoctrlDiv = document.getElementById('author_info_ctrl');
	if(null != authorinfoctrlDiv)
	{
	authorinfoctrlDiv.style.display="block";
	}
	var oaInfoDiv = document.getElementById('oa-info');
	oaInfoDiv.innerHTML = "";	
	return document.body.innerHTML;
}
	


function DisableParentPageScroll(){

	document.body.scroll = "no";
	document.body.style.overflow = 'hidden';
}

/* Function to enable parent page scrollbar */
function EnableParentPageScroll(){
	document.body.scroll = "yes";
	document.body.style.overflow = 'auto';
	var bibMulti2 = document.getElementById('bibMulti2');
	if(bibMulti2) {
		bibMulti2.style.display = 'none';
		bibMulti2.parentNode.style.display = 'none';
	}	
	
	modalOpen = false;

	if(lastFocus) {
		lastFocus.setAttribute('tabindex', '0');
		lastFocus.setAttribute('class', 'temp');
	    lastFocus.focus();
	    lastFocus = null;
	}

	mOverlay.setAttribute('aria-hidden', 'true');
}

function populateArticleInfoHtml(content,device) {
	
	injectInfoHtml(content);
	addEventListner();
	
	if(device == 'ios')
	{
	return document.body.innerHTML;
	}

};

function populateArticleInfoHtmlForAndroid(content , isUpdated , isAbstract) {
	var oaInfoDiv = document.getElementById('oa-info');
	var numChilds =	oaInfoDiv.childNodes.length;

	if(numChilds == 0 ){
	    if(content){
	       injectInfoHtml(content);
	       if(isAbstract == false){
	          var htmlToBeWritten = document.documentElement.innerHTML;
	          MyJavaScriptInterface.writeHtmlToSdCard(htmlToBeWritten);
	       }
	    }

	} else {
	    if(isUpdated == true){
		if(content){
		   injectInfoHtml(content);

		} else {
		   var elem = document.getElementById("oa-info");
		   while (elem.firstChild) {
		       elem.removeChild(elem.firstChild);
		   }
		   
		}
	        if(isAbstract == false){
		   var htmlToBeWritten = document.documentElement.innerHTML;
		   MyJavaScriptInterface.writeHtmlToSdCard(htmlToBeWritten);
		}
		MyJavaScriptInterface.resetOAInfoUpdateFlag(false);
	    } 
	    else{
		addEventListner();
	    }
	}

};

function injectInfoHtml(content){

   var oaInfoDiv = document.getElementById('oa-info');
	oaInfoDiv.innerHTML = content;
	var isDisplay = oaInfoDiv.style.display;
		if (isDisplay === 'none') {
		oaInfoDiv.style.display = 'block'
		}
	//document.getElementById('author_info_ctrl').innerHTML = content;
	var authorAffiliationDiv = document.getElementById('author-affiliation-div');
	if(null != authorAffiliationDiv) {
		document.getElementById('content_change').innerHTML = authorAffiliationDiv.innerHTML;	
	}
	var authorinfoctrlDiv = document.getElementById('author_info_ctrl');
	if(null != authorinfoctrlDiv)
	{
	authorinfoctrlDiv.style.display="none";
	}
	
	addEventListner();

}


function checkUserInfo(){

var cu_wrapperDiv = document.getElementById('show_hide');
	if(cu_wrapperDiv != null) {
	return 'yes';
	}
	else{
	return 'no';
	}
}

document.addEventListener('keydown', EnableParentPageScroll);

function expandCollapseToggle() {
	toggle('show_hide', 'expand_collapse');
}

function authorAffiliationsInfoToggle(e) {
	if(e.target && e.target.nodeName == "A") {
		toggle(e.target.parentNode.nextSibling, e.target, true);
	}
}


function addEventListner(){
	var expandCollapse = document.getElementById('expand_collapse');
	if(expandCollapse) {
		expandCollapse.href = 'UserInfo';
		expandCollapse.removeEventListener('click', expandCollapseToggle, false);
		expandCollapse.addEventListener('click', expandCollapseToggle, false);
	}
}

document.getElementsByTagName('html')[0].className = 'isJS';
function tog(currentTag) {
	var display;
	var currParent = currentTag.parentNode;
	var currParentParent = currParent.parentNode;
	var tag2collapse = currParentParent.getElementsByTagName('div')[1];
	toOpen = !tag2collapse.style.display;	
	tag2collapse.style.display = toOpen ? 'block' : ''
								 currentTag.getElementsByTagName('span')[0].innerHTML = toOpen ? '-' : '+';
}



function zoomIn(x)
{
	var fontsize;
	switch(x)
	{
	    case 0:
	        fontsize = "1em";
	        break;
	    case 1:
	        fontsize = "1.2em";
	        break;
	    case 2:
	        fontsize = "1.4em";
	        break;
	    case 3:
	        fontsize = "1.6em";
	        break;
	    case 4:
	        fontsize = "1.8em";
	        break;
	    default:
	        fontsize = "1em";
	}
    document.body.style.fontSize = fontsize;
}



function closeIPInfo() {

	var remDiv = document.getElementById('ip_info');
	var parent = remDiv.parentNode;
	parent.removeChild(remDiv);

	//window.MyJavaScriptInterface.onCloseBanner('xxyyzz');

}


function ipInfoBanner(accessInfo) {
	var iDiv = document.createElement('div');
	iDiv.id = 'ip_info';
	iDiv.innerHTML = "<span id='access_content' class='innerSpan'>"
	+ accessInfo
	+ "</span><button id='close'><a style= 'text-decoration: none;' href='didTap://closeBanner' aria-label='close access message'>X</a></button>";


	document.body.insertBefore(iDiv, document
	.getElementById('article_header'));
}

/////////////// IP Info Banner Android - Start /////////////////////

function ipInfoBannerAndroid(accessInfo, titleId) {
	var x = document.getElementById("ip_info")
	if(!x){
		var iDiv = document.createElement('div');
		iDiv.id = 'ip_info';
		iDiv.innerHTML = "<span id='access_content' class='innerSpan'>"
			+ accessInfo
			+ "</span><button id='close'><a style= 'text-decoration: none;' href='#' onclick='closeIPInfoAndroid(\""+titleId+"\")' aria-label='close access message'>x</a></button>";
		document.body.insertBefore(iDiv, document.getElementById('article_header'));
	}
}

function closeIPInfoAndroid(titleId) {
	var remDiv = document.getElementById('ip_info');
	var parent = remDiv.parentNode;
	parent.removeChild(remDiv);
	window.MyJavaScriptInterface.onCloseBanner(titleId); 
}

function closeIPInfoWithoutTitleAndroid() {
	var remDiv = document.getElementById('ip_info');
	var parent = remDiv.parentNode;
	parent.removeChild(remDiv);
}

(function closeExpandCollapseEle() {
	var authorInfo = document.getElementsByClassName('author_info');
	for(var i = 0; i < authorInfo.length; i++) {
		authorInfo[i].style.display = 'none';
		var authorInfoPrevChildArr = authorInfo[i].previousSibling.children;
		for(var j = 0; j < authorInfoPrevChildArr.length; j++) {		
			if(authorInfoPrevChildArr[j].id == 'image_div_link') {
				authorInfoPrevChildArr[j].innerHTML = '<span id="plusminus">+</span> Author Affiliations & Information';
			}
		}
	}
	
	var articleInfo = document.getElementsByClassName('article_drop_menu_inner');
	for(var x = 0; x < articleInfo.length; x++) {
		articleInfo[x].style.display = 'none';
		var articleInfoPrevChildArr = articleInfo[x].previousSibling.children;
		for(var y = 0; y < articleInfoPrevChildArr.length; y++) {	
			if(articleInfoPrevChildArr[y].id == 'expand_collapse') {
				articleInfoPrevChildArr[y].innerHTML = '<span class="accor_btn">+</span>Article Info';
			}
		}
	}
})();
/////////////// IP Info Banner Android - End /////////////////////
